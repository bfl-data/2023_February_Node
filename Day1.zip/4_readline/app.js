// const readline = require('readline');
// // console.log(readline);

// const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout
// });

// rl.question("Please enter a number: ", (input) => {
//     console.log("Youe entered: ", input);
// });

// console.log("Last Line");

// rl.question("Please enter the first number: ", (input1) => {
//     rl.question("Please enter the second number: ", (input2) => {
//         var sum = parseInt(input1) + parseInt(input2);
//         console.log("Result is: ", sum);
//         rl.close();
//     });
// });

// ------------------- Convert the above code to use promise
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});