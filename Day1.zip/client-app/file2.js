var dev2;

(function (ns) {
    function hello() {
        console.log("Hello from File 2");
    }

    ns.hello = hello;
})(dev2 = dev2 || {});