const Logger = require('./Logger');
let logger;

exports.getLogger = function () {
    if (!logger)
        logger = new Logger();
    return logger;
}