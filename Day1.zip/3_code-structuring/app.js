// // require('./logger.js');
// // require('./logger.js');

// // const logger1 = require('./logger.js');
// // const logger2 = require('./logger.js');

// // console.log(logger1 === logger2);

// // -------------------------------

// const logger = require('./logger');
// // const logger = require('./logger/mylogger');


// const loggerService = require('./loggerService');
// loggerService.log("Hi from App");

const loggerSingle = require('./loggerSingle');
const l1 = loggerSingle.getLogger();
const l2 = loggerSingle.getLogger();

console.log(l1 === l2);

l1.log("Hi from App");
l2.log("Hi from App");