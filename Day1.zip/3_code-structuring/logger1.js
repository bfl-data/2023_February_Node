console.log("Logged from Logger.js File");
