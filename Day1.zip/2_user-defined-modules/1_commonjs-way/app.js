// require('./lib.js');

// const lib = require('./lib.js');
// // console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// console.log(lib.log("From App"));

// const lib = require('./lib.js');
// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

const { Employee } = require('./lib.js');
let e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());