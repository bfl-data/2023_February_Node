// console.log("This is lib module");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// --------- Named Exports

// var fname = "Manish";
// var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function (message) {
//     return `From Lib - ${message.toUpperCase()}`
// };

// --------- Named Exports Variation

var fname = "Manish";
var lname = "Sharma";

exports.firstname = fname;
exports.lastname = lname;

exports.log = function (message) {
    return `From Lib - ${message.toUpperCase()}`
};

// -----------------------

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}

exports.Employee = Employee;
