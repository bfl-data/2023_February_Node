const express = require('express');
const router = express.Router();
const cors = require('cors');

const accountCtrl = require('../controllers/account-controller');

router.use(cors());

router.post('/getToken', accountCtrl.createToken);

module.exports = router;