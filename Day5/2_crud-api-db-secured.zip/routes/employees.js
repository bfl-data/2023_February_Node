const express = require('express');
const router = express.Router();

const empCtrl = require('../controllers/employees-controller');

router.get('/', empCtrl.index);

module.exports = router;
