const fs = require('fs').promises;

// fs.readFile('./file1.txt', 'utf-8').then(data => {
//     console.log(data);
// }).catch(err => {
//     console.log(err);
// });

async function readFile(filePath) {
    try {
        var data = await fs.readFile('./file1.txt', 'utf-8');
        console.log(data);
    } catch(err) {
        console.log(err);
    }
}

readFile('./file1.txt');