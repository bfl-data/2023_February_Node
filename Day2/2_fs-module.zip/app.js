const fs = require('fs');

// Sync
// try {
//     var data = fs.readFileSync('./file1.txt', 'utf-8');
//     console.log(data);
// } catch(err) {
//     console.log(err);
// }

// Async
// fs.readFile('./file1.txt', 'utf-8', (err, data) => {
//     if (err)
//         console.log(err);
//     else
//         console.log(data);
// });

// var message = "Hello from Node Application";
// fs.writeFile('./file2.txt', message, 'utf-8', (err) => {
//     if (err)
//         console.log(err);
//     else
//         console.log("File Write Completed");
// });

var message = "Hello from Node Application\n";
fs.appendFile('./file3.txt', message, 'utf-8', (err) => {
    if (err)
        console.log(err);
    else
        console.log("File Append Completed");
});

console.log("\nLast line in the code\n");