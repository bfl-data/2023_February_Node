const StringEmitter = require('./string-emitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// Call 1 = 1000
// Call 2 = 3000
// Call 3 = 1000

// ------------------------

// sEmitter.pushString((s)=>{
//     console.log(s);
// });

// sEmitter.pushString((s) => {
//     console.log("S1 - ", s);
// });

// sEmitter.pushString((s) => {
//     console.log("S2 - ", s);
// });

// -----------------------

sEmitter.on("data", (s) => {
    console.log("S1 - ", s);
});

// sEmitter.on("data", (s) => {
//     console.log("S2 - ", s);
// });

let count = 0;

function S2(s) {
    console.log("S2 - ", s);
    ++count;
    if (count > 2) {
        sEmitter.removeListener('data', S2);     // Unsubscribe
    }
}

sEmitter.on("data", S2);        // Subscribe