const Email = require('./Email');
const SMS = require('./SMS');

module.exports = {
    emailUtility: new Email(),
    smsUtility: new SMS()
};