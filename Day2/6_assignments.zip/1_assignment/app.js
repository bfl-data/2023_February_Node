const Account = require('./Account');
const { smsUtility, emailUtility } = require('./utilities');

let a1 = new Account(1, 1000, 6);

a1.on("depositSuccess", (balance) => {
    console.log("\nAmount Deposited Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    console.log("\nAmount Withdrawn Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    console.log("\nAmount Withdraw Failed...");
    console.log(`Account Balance is: INR ${balance}`);
});

// Code to send SMS
a1.on("depositSuccess", (balance) => {
    smsUtility.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    smsUtility.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    smsUtility.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

// Code to send Email
a1.on("depositSuccess", (balance) => {
    emailUtility.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    emailUtility.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    emailUtility.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

a1.deposit(1000);
a1.withdraw(2000);
a1.withdraw(1000);