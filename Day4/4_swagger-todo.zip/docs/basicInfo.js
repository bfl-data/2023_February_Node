module.exports = {
    openapi: "3.0.3",
    info: {
        version: "1.0.0",
        title: "Todos",
        description: "Todos API",
        contact: {
            name: "Manish Sharma",
            email: "manish.sharma@technizerindia.com",
            url: "https://www.technizerindia.com"
        }
    }
};