module.exports = {
    get: {
        tags: ['Todo CRUD Operations'],
        description: "Get a todo",
        operationId: 'getTodo',
        parameters: [
            {
                name: "_id",
                in: "path",
                schema: {
                    $ref: '#/components/schemas/_id'
                },
                required: true,
                description: "A single todo record id"
            }
        ],
        responses: {
            '200': {
                description: "Todo is obtained",
                content: {
                    'application/json': {
                        schema: {
                            $ref: '#/components/schemas/Todo'
                        }
                    }
                }
            },
            '404': {
                description: "Todo is not found",
                content: {
                    'application/json': {
                        schema: {
                            $ref: '#/components/schemas/Error',
                            example: {
                                message: "We can't find the todo item",
                                internal_code: "Invalid Id"
                            }
                        }
                    }
                }
            },
            '401': {
                $ref: '#/components/responses/UnauthorizedError'
            }
        }
    }
};