module.exports = {
    get: {
        tags: ['Todo CRUD Operations'],
        description: "Get todos",
        operationId: 'getTodos',
        parameters: [],
        responses: {
            '200': {
                description: "Todos are obtained",
                content: {
                    'application/json': {
                        schema: {
                            $ref: '#/components/schemas/Todo'
                        }
                    }
                }
            },
            '401': {
                $ref: '#/components/responses/UnauthorizedError'
            }
        }
    }
};