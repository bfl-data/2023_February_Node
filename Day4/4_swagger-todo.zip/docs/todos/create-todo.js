module.exports = {
    post: {
        tags: ['Todo CRUD Operations'],
        description: "Create todo",
        operationId: 'createTodo',
        parameters: [],
        requestBody: {
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/TodoInput'
                    }
                }
            }
        },
        responses: {
            '201': {
                description: "Todo created successfully"
            },
            '500': {
                description: "Server Error"
            },
            '401': {
                $ref: '#/components/responses/UnauthorizedError'
            }
        }
    }
};