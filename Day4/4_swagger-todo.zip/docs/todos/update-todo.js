module.exports = {
    put: {
        tags: ['Todo CRUD Operations'],
        description: "Update todo",
        operationId: 'updateTodo',
        parameters: [
            {
                name: "_id",
                in: "path",
                schema: {
                    $ref: "#/components/schemas/_id"
                },
                required: true,
                description: "Record Id of todo to be updated"
            }
        ],
        requestBody: {
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/TodoInput'
                    }
                }
            }
        },
        responses: {
            '200': {
                description: "Todo updated successfully"
            },
            '404': {
                description: "Todo not found"
            },
            '500': {
                description: "Server Error"
            },
            '401': {
                $ref: '#/components/responses/UnauthorizedError'
            }
        }
    }
};