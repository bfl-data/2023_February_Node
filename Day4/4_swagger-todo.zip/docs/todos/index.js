const createTodo = require("./create-todo");
const deleteTodo = require("./delete-todo");
const getTodo = require("./get-todo");
const getTodos = require("./get-todos");
const updateTodo = require("./update-todo");

module.exports = {
    paths: {
        '/todos': {
            ...getTodos,
            ...createTodo
        },
        '/todos/{_id}': {
            ...getTodo,
            ...updateTodo,
            ...deleteTodo
        }
    }
};