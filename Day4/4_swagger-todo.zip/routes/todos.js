const express = require('express');
const router = express.Router();

const {
  getTodos,
  getTodo,
  createTodo,
  updateTodo,
  deleteTodo
} = require('../controllers/todo-api-controller');

router.get('/', getTodos);

router.get('/:rid', getTodo);

router.post('/', createTodo);

router.put('/:rid', updateTodo);

router.delete('/:rid', deleteTodo);

module.exports = router;