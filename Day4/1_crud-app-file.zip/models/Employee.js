class Employee {
    constructor(id, name) {
        this.id = parseInt(id);
        this.name = name;
    }
}

module.exports = Employee;