const { readData, writeData } = require('../utilities/file-handler');

let employees = [];

(function () {
    readData().then(data => {
        employees = data;
    }).catch(err => {
        employees = []
    });
})();

exports.getAllEmployees = function () {
    return new Promise((resolve, reject) => {
        if (employees.length)
            resolve(employees);
        else
            reject("Employees not found");
    });
}

exports.getEmployee = function (id) {
    return new Promise((resolve, reject) => {
        if (employees.length)
            resolve(employees.find(e => e.id === parseInt(id)));
        else
            reject("Employee not found");
    });
}

exports.insertEmployee = function (employeeToInsert) {
    return new Promise((resolve, reject) => {
        employees = [...employees, employeeToInsert];
        writeData(employees).then(data => {
            employees = data;
            resolve(employees.find(e => e.id === Number(employeeToInsert.id)));
        }).catch(err => {
            reject(err);
        });
    });
}

exports.updateEmployee = function (employeeToUpdate) {
    return new Promise((resolve, reject) => {
        var itemIndex = employees.findIndex(e => e.id === parseInt(employeeToUpdate.id));
        var tempEmployees = [...employees];
        tempEmployees.splice(itemIndex, 1, { ...employeeToUpdate });
        employees = [...tempEmployees];

        writeData(employees).then(data => {
            employees = data;
            resolve(employees.find(e => e.id === Number(employeeToUpdate.id)));
        }).catch(err => {
            reject(err);
        });
    });
}

exports.deleteEmployee = function (id) {
    return new Promise((resolve, reject) => {
        employees = [...employees.filter(e => e.id !== parseInt(id))];
       
        writeData(employees).then(data => {
            employees = data;
            resolve("Success, Delete Employee");
        }).catch(err => {
            reject(err);
        });
    });
}