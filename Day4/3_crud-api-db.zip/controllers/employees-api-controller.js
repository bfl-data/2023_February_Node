const da = require("../data-access");

exports.getAll = (req, res) => {
    da.getAllEmployees().then(result => {
        res.status(200).json({ data: result, message: "Success, getting Employees" });
    }).catch(eMsg => {
        res.status(500).json({ data: [], message: "Error, getting Employees" });
    });
}

exports.get = (req, res) => {
    var _id = req.params.rid;
    da.getEmployee(_id).then(result => {
        res.status(200).json({ data: result, message: "Success, getting Employee" });
    }).catch(eMsg => {
        res.status(500).json({ data: null, message: "Error, getting Employee" });
    });
}

exports.create = (req, res) => {
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    da.insertEmployee(employee).then(result => {
        res.status(201).json({ data: result, message: "Success, Creating Employee" });
    }).catch(eMsg => {
        res.status(500).json({ data: null, message: "Error, Creating Employee" });
    });
}

exports.edit = (req, res) => {
    var _id = req.params.rid;
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    da.updateEmployee(_id, employee).then(result => {
        res.status(200).json({ data: result, message: "Success, Updating Employee" });
    }).catch(eMsg => {
        res.status(500).json({ data: null, message: "Error, Updating Employee" });
    });
}

exports.delete = (req, res) => {
    var _id = req.params.rid;

    da.deleteEmployee(_id).then(result => {
        res.status(204).json({ data: null, message: "Success, Deleting Employee" });
    }, eMsg => {
        res.status(500).json({ data: null, message: "Error, Deleting Employee" });
    });
}