const express = require('express');
const cors = require('cors');

const router = express.Router();

const employeesApiCtrl = require('../controllers/employees-api-controller');

router.use(cors());

// GET - /api/employees (Get All Employees)
router.get('/', employeesApiCtrl.getAll);

// GET - /api/employees/ahjsdghjadg (Get Employee By Id)
router.get('/:rid', employeesApiCtrl.get);

// POST - /api/employees (Create an Employee)
router.post('/', employeesApiCtrl.create);

// PUT - /api/employees/jasdkadhha (Update an Employee)
router.put('/:rid', employeesApiCtrl.edit);

// DELETE - /api/employees/jasdkadhha (Delete an Employee)
router.delete('/:rid', employeesApiCtrl.delete);

module.exports = router;
