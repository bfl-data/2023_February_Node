const Employee = require('../models/Employee');

exports.getAllEmployees = async function () {
    try {
        const allEmployees = await Employee.find();
        return allEmployees;
    } catch (error) {
        console.log(`Could not fetch Employees ${error}`);
    }
}

exports.getEmployee = async function (recordId) {
    try {
        const singleEmployee = await Employee.findById({_id: recordId});
        return singleEmployee;
    } catch (error) {
        console.log(`Could not fetch Employee ${error}`);
    }
}

exports.insertEmployee = async function (employeeToInsert) {
    try {
        const response = await new Employee(employeeToInsert).save();
        return response;
    } catch (error) {
        console.log(`Could not create Employee ${error}`);
    }
}

exports.updateEmployee = async function (recordId, employeeToUpdate) {
    try {
        const updateResponse = await Employee.findOneAndUpdate({_id: recordId}, employeeToUpdate);
        return updateResponse;
    } catch (error) {
        console.log(`Could not update Employee ${error}`);
    }
}

exports.deleteEmployee = async function (recordId) {
    try {
        const deletedResponse = await Employee.findOneAndDelete({_id: recordId});
        return deletedResponse;
    } catch (error) {
        console.log(`Could not delete Employee ${error}`);
    }
}