$(document).ready(function () {
    $("#btnLoad").click(function () {
        // alert("Button was clicked...");

        // Ajax Call
        $("#t_body").empty();

        $.ajax({
            url: 'api/employees',
            type: 'GET',
            dataType: 'json',
            success: function (resData) {
                if (resData.data.length > 0) {
                    var tmpl = $.templates("#empRowTemplate");
                    var html = tmpl.render(resData.data);
                    $("#t_body").append(html);
                }
            }, error: function (err) {
                console.error(err);
            }
        })
    });
});